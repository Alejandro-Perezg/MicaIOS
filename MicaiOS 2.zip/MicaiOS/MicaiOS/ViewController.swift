//
//  ViewController.swift
//  MicaiOS
//
//  Created by user194036 on 11/16/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

